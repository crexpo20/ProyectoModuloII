USE [NorthWindDW];
GO
/* Conteo de dimensiones y tabla de hechos */
SELECT 'Dim_Cliente' AS Tabla, COUNT(*) AS Filas FROM dbo.Dim_Cliente
UNION ALL SELECT 'Dim_Empleado', COUNT(*) FROM dbo.Dim_Empleado
UNION ALL SELECT 'Dim_Producto', COUNT(*) FROM dbo.Dim_Producto
UNION ALL SELECT 'Dim_Tiempo', COUNT(*) FROM dbo.Dim_Tiempo
UNION ALL SELECT 'Dim_Transportista', COUNT(*) FROM dbo.Dim_Transportista
UNION ALL SELECT 'Fact_Ventas', COUNT(*) FROM dbo.Fact_Ventas;
GO
/* Muestra de hechos */
SELECT TOP (25) OrderID, SK_Tiempo, SK_Cliente, SK_Producto,
       Quantity, UnitPrice, Discount, ExtendedPrice, Freight
FROM dbo.Fact_Ventas
ORDER BY OrderID, SK_Producto;
GO
/* Comparar flete original por pedido contra suma distribuida en el DW. Diferencia debe ser 0.00. */
WITH FleteDW AS (
 SELECT OrderID, CAST(SUM(Freight) AS decimal(19,2)) AS FleteAsignado
 FROM dbo.Fact_Ventas GROUP BY OrderID
)
SELECT o.OrderID, CAST(o.Freight AS decimal(19,2)) AS FleteOriginal,
       COALESCE(f.FleteAsignado, 0) AS FleteEnDW,
       CAST(CAST(o.Freight AS decimal(19,2)) - COALESCE(f.FleteAsignado, 0) AS decimal(19,2)) AS Diferencia
FROM NorthWind.dbo.Orders AS o
LEFT JOIN FleteDW AS f ON f.OrderID = o.OrderID
ORDER BY o.OrderID;
GO
