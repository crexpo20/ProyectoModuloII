/*
Carga la tabla de hechos con una fila por pedido y producto.
Freight original viene de NorthWind.dbo.Orders.Freight y es un importe por PEDIDO.
Como Fact_Ventas tiene una fila por PRODUCTO dentro del pedido, este script reparte el flete
proporcionalmente al importe neto de cada línea. El último producto recibe el residuo de redondeo,
para que la suma de Freight asignado por pedido sea igual al flete original.
*/
USE [NorthWindDW];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
BEGIN TRY
 BEGIN TRAN;
 DELETE FROM dbo.Fact_Ventas;

 ;WITH Lineas AS (
   SELECT o.OrderID, o.CustomerID, o.EmployeeID, o.ShipVia, CAST(o.OrderDate AS date) AS OrderDate,
          CAST(o.Freight AS decimal(19,4)) AS FletePedido,
          od.ProductID, od.UnitPrice, od.Quantity, od.Discount,
          CAST(od.UnitPrice * od.Quantity * (1.0 - od.Discount) AS decimal(19,4)) AS ImporteNeto
   FROM NorthWind.dbo.Orders AS o
   INNER JOIN NorthWind.dbo.[Order Details] AS od ON od.OrderID = o.OrderID
 ), Totales AS (
   SELECT *, SUM(ImporteNeto) OVER (PARTITION BY OrderID) AS TotalNetoPedido,
          ROW_NUMBER() OVER (PARTITION BY OrderID ORDER BY ProductID) AS NumLinea,
          COUNT(*) OVER (PARTITION BY OrderID) AS CantLineas
   FROM Lineas
 ), Reparto AS (
   SELECT *,
     CAST(CASE WHEN TotalNetoPedido > 0
          THEN ROUND(FletePedido * ImporteNeto / TotalNetoPedido, 2)
          ELSE 0 END AS decimal(19,2)) AS FleteRedondeado
   FROM Totales
 ), RepartoFinal AS (
   SELECT *,
     CASE WHEN NumLinea = CantLineas THEN
       CAST(FletePedido - COALESCE(SUM(FleteRedondeado) OVER (
          PARTITION BY OrderID ORDER BY ProductID ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
       ), 0) AS decimal(19,2))
       ELSE FleteRedondeado END AS FleteAsignado
   FROM Reparto
 )
 INSERT dbo.Fact_Ventas
   (OrderID, SK_Tiempo, SK_Cliente, SK_Producto, SK_Empleado, SK_Transportista,
    Quantity, UnitPrice, Discount, ExtendedPrice, Freight)
 SELECT r.OrderID,
        dt.SK_Tiempo,
        dc.SK_Cliente,
        dp.SK_Producto,
        de.SK_Empleado,
        ds.SK_Transportista,
        r.Quantity,
        r.UnitPrice,
        r.Discount,
        CAST(r.ImporteNeto AS money),
        CAST(r.FleteAsignado AS money)
 FROM RepartoFinal AS r
 INNER JOIN dbo.Dim_Tiempo AS dt ON dt.Fecha = r.OrderDate
 INNER JOIN dbo.Dim_Cliente AS dc ON dc.CustomerID = r.CustomerID
 INNER JOIN dbo.Dim_Producto AS dp ON dp.ProductID = r.ProductID
 INNER JOIN dbo.Dim_Empleado AS de ON de.EmployeeID = r.EmployeeID
 INNER JOIN dbo.Dim_Transportista AS ds ON ds.ShipperID = r.ShipVia;

 COMMIT;
END TRY
BEGIN CATCH
 IF @@TRANCOUNT > 0 ROLLBACK;
 THROW;
END CATCH;
GO
SELECT COUNT(*) AS FilasFactVentas, SUM(ExtendedPrice) AS VentasNetas, SUM(Freight) AS FletesAsignados
FROM dbo.Fact_Ventas;
GO
