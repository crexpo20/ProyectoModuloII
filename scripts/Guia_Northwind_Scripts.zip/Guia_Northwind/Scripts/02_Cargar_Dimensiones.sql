/*
Carga las dimensiones del proyecto NorthWindDW.
PRERREQUISITOS:
1) Restaurar el respaldo original como NorthWind.
2) Publicar/crear la estructura de NorthWindDW desde NorthWindDW.sqlproj en Visual Studio.
3) Ejecutar este archivo en SSMS.
Este script vuelve a cargar las dimensiones; primero elimina los hechos para no dejar claves colgantes.
*/
USE [NorthWindDW];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
BEGIN TRY
 BEGIN TRAN;

 DELETE FROM dbo.Fact_Ventas;
 DELETE FROM dbo.Dim_Cliente;
 DELETE FROM dbo.Dim_Empleado;
 DELETE FROM dbo.Dim_Producto;
 DELETE FROM dbo.Dim_Tiempo;
 DELETE FROM dbo.Dim_Transportista;

 DBCC CHECKIDENT ('dbo.Dim_Cliente', RESEED, 0) WITH NO_INFOMSGS;
 DBCC CHECKIDENT ('dbo.Dim_Empleado', RESEED, 0) WITH NO_INFOMSGS;
 DBCC CHECKIDENT ('dbo.Dim_Producto', RESEED, 0) WITH NO_INFOMSGS;
 DBCC CHECKIDENT ('dbo.Dim_Transportista', RESEED, 0) WITH NO_INFOMSGS;

 INSERT dbo.Dim_Cliente (CustomerID, CompanyName, ContactName, City, Region, Country, CustomerDesc)
 SELECT c.CustomerID, c.CompanyName, c.ContactName, c.City, c.Region, c.Country, NULL
 FROM NorthWind.dbo.Customers AS c;

 INSERT dbo.Dim_Empleado (EmployeeID, NombreCompleto, Title, City, Country, TerritoryDescription, RegionDescription)
 SELECT e.EmployeeID,
        LEFT(CONCAT(e.FirstName, N' ', e.LastName), 31),
        e.Title, e.City, e.Country,
        terr.TerritoryDescription, reg.RegionDescription
 FROM NorthWind.dbo.Employees AS e
 OUTER APPLY (
   SELECT MAX(t.TerritoryDescription) AS TerritoryDescription,
          MAX(r.RegionDescription) AS RegionDescription
   FROM NorthWind.dbo.EmployeeTerritories AS et
   INNER JOIN NorthWind.dbo.Territories AS t ON t.TerritoryID = et.TerritoryID
   INNER JOIN NorthWind.dbo.Region AS r ON r.RegionID = t.RegionID
   WHERE et.EmployeeID = e.EmployeeID
 ) AS terr
 OUTER APPLY (
   SELECT MAX(r.RegionDescription) AS RegionDescription
   FROM NorthWind.dbo.EmployeeTerritories AS et
   INNER JOIN NorthWind.dbo.Territories AS t ON t.TerritoryID = et.TerritoryID
   INNER JOIN NorthWind.dbo.Region AS r ON r.RegionID = t.RegionID
   WHERE et.EmployeeID = e.EmployeeID
 ) AS reg;

 INSERT dbo.Dim_Producto (ProductID, ProductName, CategoryName, CategoryDescription, SupplierName, SupplierCountry, Discontinued)
 SELECT p.ProductID, p.ProductName, c.CategoryName, c.Description,
        s.CompanyName, s.Country, p.Discontinued
 FROM NorthWind.dbo.Products AS p
 LEFT JOIN NorthWind.dbo.Categories AS c ON c.CategoryID = p.CategoryID
 LEFT JOIN NorthWind.dbo.Suppliers AS s ON s.SupplierID = p.SupplierID;

 INSERT dbo.Dim_Transportista (ShipperID, CompanyName)
 SELECT s.ShipperID, s.CompanyName
 FROM NorthWind.dbo.Shippers AS s;

 /* Calendario con una fila por cada fecha de pedido. Clave de fecha YYYYMMDD. */
 ;WITH Fechas AS (
   SELECT DISTINCT CAST(OrderDate AS date) AS Fecha
   FROM NorthWind.dbo.Orders
   WHERE OrderDate IS NOT NULL
 )
 INSERT dbo.Dim_Tiempo (SK_Tiempo, Fecha, Anio, Trimestre, Mes, NombreMes, Dia, DiaSemana, NombreDiaSemana)
 SELECT CONVERT(int, CONVERT(char(8), Fecha, 112)), Fecha,
        YEAR(Fecha), DATEPART(QUARTER, Fecha), MONTH(Fecha),
        CASE MONTH(Fecha)
          WHEN 1 THEN N'Enero' WHEN 2 THEN N'Febrero' WHEN 3 THEN N'Marzo'
          WHEN 4 THEN N'Abril' WHEN 5 THEN N'Mayo' WHEN 6 THEN N'Junio'
          WHEN 7 THEN N'Julio' WHEN 8 THEN N'Agosto' WHEN 9 THEN N'Septiembre'
          WHEN 10 THEN N'Octubre' WHEN 11 THEN N'Noviembre' ELSE N'Diciembre' END,
        DAY(Fecha), ((DATEDIFF(DAY, CONVERT(date,'19000101'), Fecha) % 7) + 1),
        CASE ((DATEDIFF(DAY, CONVERT(date,'19000101'), Fecha) % 7) + 1)
          WHEN 1 THEN N'Lunes' WHEN 2 THEN N'Martes' WHEN 3 THEN N'Miércoles'
          WHEN 4 THEN N'Jueves' WHEN 5 THEN N'Viernes' WHEN 6 THEN N'Sábado' ELSE N'Domingo' END
 FROM Fechas;

 COMMIT;
END TRY
BEGIN CATCH
 IF @@TRANCOUNT > 0 ROLLBACK;
 THROW;
END CATCH;
GO
/* Verificación de filas cargadas */
SELECT 'Dim_Cliente' AS Tabla, COUNT(*) AS Filas FROM dbo.Dim_Cliente
UNION ALL SELECT 'Dim_Empleado', COUNT(*) FROM dbo.Dim_Empleado
UNION ALL SELECT 'Dim_Producto', COUNT(*) FROM dbo.Dim_Producto
UNION ALL SELECT 'Dim_Tiempo', COUNT(*) FROM dbo.Dim_Tiempo
UNION ALL SELECT 'Dim_Transportista', COUNT(*) FROM dbo.Dim_Transportista;
GO
